/**
 * ISAPI - Face Recognition Terminals (Value Series)
 * Hikvision ISAPI Reference — kaihome SRL / jcgonzalez.01@gmail.com
 *
 * Covered models (DS-K1A330, DS-K1T320*, DS-K1T321*, DS-K1T323*, DS-K1T331,
 * DS-K1T341*, DS-K1T342*, DS-K1T343*, DS-K1T344*, DS-K1T6Q*, DS-K1T6QT*, etc.)
 *
 * Base URL: http(s)://<device_ip>:<port>
 * Default HTTP port: 80   HTTPS: 443
 * Auth: HTTP Digest (default) — always use HTTPS in production
 */

// ─────────────────────────────────────────────────────────────
// NAMESPACE MAP  (for grouping endpoints logically)
// ─────────────────────────────────────────────────────────────
export const ISAPI_NS = {
  SYSTEM:        "/ISAPI/System",
  ACCESS:        "/ISAPI/AccessControl",
  EVENT:         "/ISAPI/Event/notification",
  FACE_LIB:      "/ISAPI/Intelligent/FDLib",
  FACE_ANALYSIS: "/ISAPI/SDT/Face",
  SECURITY:      "/ISAPI/Security",
  SECURITY_CP:   "/ISAPI/SecurityCP",
  VIDEO_INTERCOM:"/ISAPI/VideoIntercom",
  CONTENT_MGMT:  "/ISAPI/ContentMgmt",
};

// ─────────────────────────────────────────────────────────────
// SYSTEM ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const SYSTEM = {
  // Device info & capabilities
  CAPABILITIES:             "GET  /ISAPI/System/capabilities",
  DEVICE_INFO:              "GET  /ISAPI/System/deviceInfo",
  FIRMWARE_CODE:            "GET  /ISAPI/System/firmwareCodeV2",
  DEVICE_LANGUAGE:          "GET  /ISAPI/System/DeviceLanguage",
  SET_DEVICE_LANGUAGE:      "PUT  /ISAPI/System/DeviceLanguage",
  USER_MANUAL_LINK:         "GET  /ISAPI/System/GetUserManualLink",

  // Activation & reset
  ACTIVATE:                 "PUT  /ISAPI/System/activate",
  FACTORY_RESET:            "PUT  /ISAPI/System/factoryReset",
  REBOOT:                   "PUT  /ISAPI/System/reboot",

  // Time & NTP
  TIME:                     "GET  /ISAPI/System/time",
  SET_TIME:                 "PUT  /ISAPI/System/time",
  TIME_CAPABILITIES:        "GET  /ISAPI/System/time/capabilities",
  TIME_TIMEZONE:            "GET  /ISAPI/System/time/timeZone",
  SET_TIMEZONE:             "PUT  /ISAPI/System/time/timeZone",
  NTP_SERVERS:              "GET  /ISAPI/System/time/ntpServers",
  SET_NTP_SERVERS:          "PUT  /ISAPI/System/time/ntpServers",
  NTP_SERVERS_CAP:          "GET  /ISAPI/System/time/ntpServers/capabilities",
  NTP_CONFIG:               "GET  /ISAPI/System/time/ntp",
  SET_NTP_CONFIG:           "PUT  /ISAPI/System/time/ntp",
  NTP_CAPABILITIES:         "GET  /ISAPI/System/time/ntp/capabilities",
  NTP_SERVICE:              "GET  /ISAPI/System/time/NTPService",
  SET_NTP_SERVICE:          "PUT  /ISAPI/System/time/NTPService",
  NTP_SERVICE_CAP:          "GET  /ISAPI/System/time/NTPService/capabilitis",
  TIME_STATE_PARAM:         "GET  /ISAPI/System/time/TimeStateParam",
  TIMEZONE_LOCK:            "GET  /ISAPI/System/time/TimeZoneLock",
  SEARCH_IANA_LIST:         "POST /ISAPI/System/time/SearchDeviceIANAList",

  // Firmware upgrade
  UPGRADE_FIRMWARE:         "POST /ISAPI/System/updateFirmware",
  UPGRADE_STATUS:           "GET  /ISAPI/System/upgradeStatus",
  ONLINE_UPGRADE_CAP:       "GET  /ISAPI/System/onlineUpgrade/capabilities",
  ONLINE_UPGRADE_INSPECT:   "POST /ISAPI/System/onlineUpgrade/PatrolInspection",
  ONLINE_UPGRADE_TASK:      "POST /ISAPI/System/onlineUpgrade/task",
  ONLINE_UPGRADE_APPLY:     "PUT  /ISAPI/System/onlineUpgrade/upgrade",
  ONLINE_UPGRADE_STATUS:    "GET  /ISAPI/System/onlineUpgrade/status",
  ONLINE_UPGRADE_TASK_STATUS:"GET /ISAPI/System/onlineUpgrade/status/task",
  ONLINE_UPGRADE_SEARCH:    "GET  /ISAPI/System/onlineUpgrade/SearchStatus",
  ONLINE_UPGRADE_CANCEL:    "PUT  /ISAPI/System/onlineUpgrade/CancelUpgrade",

  // Peripheral upgrade (ACS sub-devices: card readers, locks, etc.)
  ACS_UPDATE_CAP:           "GET  /ISAPI/System/AcsUpdate/capabilities",
  // POST /ISAPI/System/updateFirmware?type=<type>&moduleAddress=<addr>

  // Bulk child-device upgrade
  BULK_UPGRADE_CAP:         "GET  /ISAPI/System/BulkUpgradeChildDevice/capabilities",
  BULK_UPGRADE_START:       "POST /ISAPI/System/BulkUpgradeChildDeviceList",
  BULK_UPGRADE_SEARCH:      "POST /ISAPI/System/BulkUpgradeChildDeviceList/Search",
  BULK_UPGRADE_MODIFY:      "PUT  /ISAPI/System/ModifyBulkUpgradeChildDeviceTask",
  BULK_UPGRADE_DELETE:      "PUT  /ISAPI/System/DeleteBulkUpgradeChildDeviceTask",
  SEARCH_IOT_CHILDREN:      "POST /ISAPI/IoTGateway/Childmanage/SearchChild",

  // Network
  NETWORK_CAPABILITIES:     "GET  /ISAPI/System/Network/capabilities",
  SSH:                      "PUT  /ISAPI/System/Network/ssh",
  DSTP_PROTOCOLS_CAP:       "GET  /ISAPI/System/Network/DSTPAccess/DSTPProtocolsCap",
  SET_DSTP_SERVER:          "PUT  /ISAPI/System/Network/DSTPAccess/DSTPServerCfg",

  // Packet capture
  NETWORK_CAPTURE_CAP:      "GET  /ISAPI/System/networkCapture/capabilities",
  NETWORK_CAPTURE_STORAGE:  "GET  /ISAPI/System/networkCapture/StoragePathInfo",
  NETWORK_CAPTURE_START:    "PUT  /ISAPI/System/networkCapture/manualStart",
  NETWORK_CAPTURE_STOP:     "PUT  /ISAPI/System/networkCapture/manualStop",
  NETWORK_CAPTURE_STATUS:   "GET  /ISAPI/System/networkCapture/manualStatus",
  NETWORK_CAPTURE_EXPORT:   "GET  /ISAPI/System/networkCapture/exportFile",
  NETWORK_CAPTURE_PARAMS_CAP:"GET /ISAPI/System/NetworkCaptureParams/capabilities",
  NETWORK_CAPTURE_START2:   "POST /ISAPI/System/StartNetworkCapture",
  NETWORK_CAPTURE_STOP2:    "POST /ISAPI/System/StopNetworkCapture",
  NETWORK_CAPTURE_STATUS2:  "GET  /ISAPI/System/GetNetworkCaptureStatus",

  // Serial ports
  SERIAL_CAP:               "GET  /ISAPI/System/Serial/capabilities",
  SERIAL_PORTS:             "GET  /ISAPI/System/Serial/ports",
  SERIAL_PORT:              "GET  /ISAPI/System/Serial/ports/<portID>",
  SET_SERIAL_PORT:          "PUT  /ISAPI/System/Serial/ports/<portID>",

  // Two-way audio
  AUDIO_CHANNELS:           "GET  /ISAPI/System/TwoWayAudio/channels",
  AUDIO_CHANNELS_CAP:       "GET  /ISAPI/System/TwoWayAudio/channels/capabilities",
  AUDIO_CHANNEL:            "GET  /ISAPI/System/TwoWayAudio/channels/<audioID>",
  SET_AUDIO_CHANNEL:        "PUT  /ISAPI/System/TwoWayAudio/channels/<audioID>",
  AUDIO_OPEN:               "PUT  /ISAPI/System/TwoWayAudio/channels/<audioID>/open",
  AUDIO_CLOSE:              "PUT  /ISAPI/System/TwoWayAudio/channels/<audioID>/close",
  AUDIO_DATA_RX:            "GET  /ISAPI/System/TwoWayAudio/channels/1/audioData",
  AUDIO_DATA_TX:            "PUT  /ISAPI/System/TwoWayAudio/channels/1/audioData",

  // Video
  VIDEO_CAP:                "GET  /ISAPI/System/Video/capabilities",

  // Mutex / mutually exclusive functions
  MUTEX_FUNCTION_CAP:       "GET  /ISAPI/System/mutexFunction/capabilities",

  // IOT
  IOT_CHANNEL_TEMPLATE:     "GET  /ISAPI/System/IOT/channelConfig/template",
  IOT_CHANNEL_REPORT:       "GET  /ISAPI/System/IOT/channelConfig/report",
  SET_IOT_CHANNEL:          "PUT  /ISAPI/System/IOT/channelConfig",

  // Misc
  CONTENT_MGMT_CAP:         "GET  /ISAPI/ContentMgmt/capabilities",
  INPUT_PROXY_CHANNELS:     "GET  /ISAPI/ContentMgmt/InputProxy/channels",
};

// ─────────────────────────────────────────────────────────────
// SECURITY ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const SECURITY = {
  CAPABILITIES:             "GET  /ISAPI/Security/capabilities",
  CHALLENGE:                "POST /ISAPI/Security/challenge",       // RSA key exchange
  CHECK_PHONE_CODE:         "PUT  /ISAPI/Security/resetPassword/CheckPhoneNoSecurityCode",
  RESET_PASSWORD_PHONE:     "PUT  /ISAPI/Security/resetPassword/ResetPasswordPhoneNo",
};

// ─────────────────────────────────────────────────────────────
// EVENT / ARMING ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const EVENT = {
  // Arming stream (persistent connection - keep-alive)
  ALERT_STREAM:             "GET  /ISAPI/Event/notification/alertStream",

  // Subscription-based arming
  SUBSCRIBE_CAP:            "GET  /ISAPI/Event/notification/subscribeEventCap",
  SUBSCRIBE:                "POST /ISAPI/Event/notification/subscribeEvent",
  UPDATE_SUBSCRIBE:         "PUT  /ISAPI/Event/notification/subscribeEvent/<subscribeEventID>",

  // Listening host (HTTP push receiver configuration)
  HTTP_HOSTS_CAP:           "GET  /ISAPI/Event/notification/httpHosts/capabilities",
  HTTP_HOSTS_GET:           "GET  /ISAPI/Event/notification/httpHosts",
  HTTP_HOSTS_SET:           "PUT  /ISAPI/Event/notification/httpHosts",
  HTTP_HOST_GET:            "GET  /ISAPI/Event/notification/httpHosts/<hostID>",
  HTTP_HOST_SET:            "PUT  /ISAPI/Event/notification/httpHosts/<hostID>",
  HTTP_HOST_ADD:            "POST /ISAPI/Event/notification/httpHosts",
  HTTP_HOST_DELETE:         "DELETE /ISAPI/Event/notification/httpHosts/<hostID>",
  HTTP_HOST_DELETE_ALL:     "DELETE /ISAPI/Event/notification/httpHosts",
  HTTP_HOST_TEST:           "POST /ISAPI/AddHttpHost/Test",

  // Event template
  EVENT_TEMPLATE_PARAMS:    "GET  /ISAPI/Event/notification/EventTemplateParams",
};

// ─────────────────────────────────────────────────────────────
// ACCESS CONTROL ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const ACCESS = {
  // ── Capabilities ──────────────────────────────────────────
  CAPABILITIES:             "GET  /ISAPI/AccessControl/capabilities",

  // ── Person (UserInfo) management ──────────────────────────
  USER_CAP:                 "GET  /ISAPI/AccessControl/UserInfo/capabilities",
  USER_COUNT:               "GET  /ISAPI/AccessControl/UserInfo/Count",
  USER_SEARCH:              "POST /ISAPI/AccessControl/UserInfo/Search",
  USER_APPLY:               "PUT  /ISAPI/AccessControl/UserInfo/SetUp",       // overwrite all
  USER_ADD:                 "POST /ISAPI/AccessControl/UserInfo/Record",       // add new
  USER_MODIFY:              "PUT  /ISAPI/AccessControl/UserInfo/Modify",
  USER_DELETE:              "PUT  /ISAPI/AccessControl/UserInfoDetail/Delete",
  USER_DELETE_CAP:          "GET  /ISAPI/AccessControl/UserInfoDetail/Delete/capabilities",
  USER_DELETE_PROGRESS:     "GET  /ISAPI/AccessControl/UserInfoDetail/DeleteProcess",
  // Async import (large batches)
  USER_ASYNC_IMPORT_CAP:    "GET  /ISAPI/AccessControl/UserInfo/asyncImportDatasTasks/capabilities",
  USER_ASYNC_IMPORT_LIST:   "GET  /ISAPI/AccessControl/UserInfo/asyncImportDatasTasks/",
  USER_ASYNC_IMPORT_STATUS: "GET  /ISAPI/AccessControl/UserInfo/asyncImportDatasTasks/status",
  USER_ASYNC_IMPORT_DELETE: "DELETE /ISAPI/AccessControl/UserInfo/asyncImportDatasTasks/",
  // User picture async import
  USER_PIC_ASYNC_CAP:       "GET  /ISAPI/AccessControl/UserPic/asyncImportDatasTasks/capabilities",
  USER_PIC_ASYNC_LIST:      "GET  /ISAPI/AccessControl/UserPic/asyncImportDatasTasks/",
  USER_PIC_ASYNC_STATUS:    "GET  /ISAPI/AccessControl/UserPic/asyncImportDatasTasks/status",
  USER_PIC_ASYNC_DELETE:    "DELETE /ISAPI/AccessControl/UserPic/asyncImportDatasTasks/",

  // ── Card management ───────────────────────────────────────
  CARD_CAP:                 "GET  /ISAPI/AccessControl/CardInfo/capabilities",
  CARD_COUNT:               "GET  /ISAPI/AccessControl/CardInfo/Count",
  CARD_SEARCH:              "POST /ISAPI/AccessControl/CardInfo/Search",
  CARD_APPLY:               "PUT  /ISAPI/AccessControl/CardInfo/SetUp",        // overwrite all
  CARD_ADD:                 "POST /ISAPI/AccessControl/CardInfo/Record",        // add new
  CARD_MODIFY:              "PUT  /ISAPI/AccessControl/CardInfo/Modify",
  CARD_DELETE:              "PUT  /ISAPI/AccessControl/CardInfo/Delete",
  CARD_CAPTURE:             "GET  /ISAPI/AccessControl/CaptureCardInfo",        // swipe to collect
  CARD_CAPTURE_CAP:         "GET  /ISAPI/AccessControl/CaptureCardInfo/capabilities",

  // ── Fingerprint management ────────────────────────────────
  FP_CAP:                   "GET  /ISAPI/AccessControl/FingerPrint/capabilities",  // via general cap
  FP_COUNT:                 "GET  /ISAPI/AccessControl/FingerPrint/Count",
  FP_SEARCH:                "POST /ISAPI/AccessControl/FingerPrintUpload",     // search (misleading name)
  FP_APPLY:                 "POST /ISAPI/AccessControl/FingerPrint/SetUp",     // overwrite
  FP_ADD:                   "POST /ISAPI/AccessControl/FingerPrintDownload",   // push to device
  FP_PROGRESS:              "GET  /ISAPI/AccessControl/FingerPrintProgress",
  FP_MODIFY:                "POST /ISAPI/AccessControl/FingerPrintModify",
  FP_DELETE:                "PUT  /ISAPI/AccessControl/FingerPrint/Delete",
  FP_DELETE_PROGRESS:       "GET  /ISAPI/AccessControl/FingerPrint/DeleteProcess",
  FP_CAPTURE:               "POST /ISAPI/AccessControl/CaptureFingerPrint",    // live capture
  FP_CAPTURE_CAP:           "GET  /ISAPI/AccessControl/CaptureFingerPrint/capabilities",

  // ── Iris data management ──────────────────────────────────
  IRIS_CAP:                 "GET  /ISAPI/AccessControl/IrisInfo/capabilities",
  IRIS_COUNT:               "GET  /ISAPI/AccessControl/IrisInfo/count",
  IRIS_SEARCH:              "POST /ISAPI/AccessControl/IrisInfo/search",
  IRIS_APPLY:               "PUT  /ISAPI/AccessControl/IrisInfo/setup",
  IRIS_ADD:                 "POST /ISAPI/AccessControl/IrisInfo/record",
  IRIS_MODIFY:              "PUT  /ISAPI/AccessControl/IrisInfo/modify",
  IRIS_DELETE:              "PUT  /ISAPI/AccessControl/IrisInfo/delete",
  IRIS_CAPTURE:             "POST /ISAPI/AccessControl/captureIrisData",
  IRIS_CAPTURE_PROGRESS:    "GET  /ISAPI/AccessControl/captureIrisData/progress",

  // ── Face compare config ───────────────────────────────────
  FACE_COMPARE_COND:        "GET  /ISAPI/AccessControl/FaceCompareCond",
  SET_FACE_COMPARE_COND:    "PUT  /ISAPI/AccessControl/FaceCompareCond",
  FACE_COMPARE_COND_CAP:    "GET  /ISAPI/AccessControl/FaceCompareCond/capabilities",
  FACE_CAPTURE_DATA:        "POST /ISAPI/AccessControl/CaptureFaceData",       // live face capture
  FACE_CAPTURE_DATA_CAP:    "GET  /ISAPI/AccessControl/CaptureFaceData/capabilities",
  FACE_CAPTURE_PROGRESS:    "GET  /ISAPI/AccessControl/CaptureFaceData/Progress",
  FACE_RECOGNIZE_MODE:      "GET  /ISAPI/AccessControl/FaceRecognizeMode",
  SET_FACE_RECOGNIZE_MODE:  "PUT  /ISAPI/AccessControl/FaceRecognizeMode",
  FACE_RECOGNIZE_MODE_CAP:  "GET  /ISAPI/AccessControl/FaceRecognizeMode/capabilities",

  // ── Door / access point ───────────────────────────────────
  DOOR_PARAM:               "GET  /ISAPI/AccessControl/Door/param/<doorID>",
  SET_DOOR_PARAM:           "PUT  /ISAPI/AccessControl/Door/param/<doorID>",
  SET_DOOR_PARAM_ALT:       "PUT  /ISAPI/AccessControl/Door/Param",
  DOOR_SEARCH_PARAMS:       "GET  /ISAPI/AccessControl/Door/SearchParams/capabilities",
  DOOR_SEARCH:              "POST /ISAPI/AccessControl/Door/SearchParams",
  DOOR_OPEN_PARAMS:         "GET  /ISAPI/AccessControl/Door/OpenDoorParams",
  SET_DOOR_OPEN_PARAMS:     "PUT  /ISAPI/AccessControl/Door/OpenDoorParams",
  DOOR_OPEN_PARAMS_CAP:     "GET  /ISAPI/AccessControl/Door/OpenDoorParams/capabilities",
  DOOR_LINKAGE_DEVICES_CAP: "GET  /ISAPI/AccessControl/Door/GetDoorLinkageDeviceNum/capabilities",
  DOOR_LINKAGE_DEVICES:     "POST /ISAPI/AccessControl/Door/SearchParams",    // same search
  DOOR_MAGNETIC_RULE:       "GET  /ISAPI/AccessControl/doorMagneticDefiniteRule",
  DOOR_MAGNETIC_RULE_CAP:   "GET  /ISAPI/AccessControl/doorMagneticDefiniteRule/capabilities",

  // Remote door control
  REMOTE_CONTROL_CAP:       "GET  /ISAPI/AccessControl/RemoteControl/door/capabilities",
  REMOTE_CONTROL:           "PUT  /ISAPI/AccessControl/RemoteControl/door/<doorID>",
  // Common commands: open, close, remain_open, remain_closed
  // Body: <RemoteControlDoor><cmd>open</cmd></RemoteControlDoor>

  // Remote verification (face/ID check by platform)
  REMOTE_CHECK_CAP:         "GET  /ISAPI/AccessControl/remoteCheck/capabilities",
  REMOTE_CHECK:             "PUT  /ISAPI/AccessControl/remoteCheck",

  // ── Secure Door Control Unit (SDCU) ───────────────────────
  SDCU_STATUS:              "GET  /ISAPI/AccessControl/DoorSecurityModule/moduleStatus",
  SDCU_STATUS_CAP:          "GET  /ISAPI/AccessControl/DoorSecurityModule/moduleStatus/capabilities",
  SDCU_PAIR:                "PUT  /ISAPI/AccessControl/Door/DoorSecurityModulePairParams",
  SDCU_SWITCH:              "PUT  /ISAPI/AccessControl/Door/DoorSecurityModuleSwitchParams",

  // Lock type config
  LOCK_TYPE:                "GET  /ISAPI/AccessControl/Configuration/lockType",
  SET_LOCK_TYPE:            "PUT  /ISAPI/AccessControl/Configuration/lockType",
  LOCK_TYPE_CAP:            "GET  /ISAPI/AccessControl/Configuration/lockType/capabilities",

  // ── ACS events (access log) ───────────────────────────────
  ACS_EVENT_CAP:            "GET  /ISAPI/AccessControl/AcsEvent/capabilities",
  ACS_EVENT_SEARCH:         "POST /ISAPI/AccessControl/AcsEvent",
  ACS_EVENT_COUNT:          "POST /ISAPI/AccessControl/AcsEventTotalNum",
  ACS_EVENT_COUNT_CAP:      "GET  /ISAPI/AccessControl/AcsEventTotalNum/capabilities",
  ACS_EVENT_STORAGE_CFG:    "GET  /ISAPI/AccessControl/AcsEvent/StorageCfg",
  SET_ACS_EVENT_STORAGE:    "PUT  /ISAPI/AccessControl/AcsEvent/StorageCfg",
  ACS_EVENT_STORAGE_CAP:    "GET  /ISAPI/AccessControl/AcsEvent/StorageCfg/capabilities",
  ACS_WORK_STATUS:          "GET  /ISAPI/AccessControl/AcsWorkStatus",
  ACS_WORK_STATUS_CAP:      "GET  /ISAPI/AccessControl/AcsWorkStatus/capabilities",

  // ── General ACS config (AcsCfg) ──────────────────────────
  ACS_CFG:                  "GET  /ISAPI/AccessControl/AcsCfg",
  SET_ACS_CFG:              "PUT  /ISAPI/AccessControl/AcsCfg",
  ACS_CFG_CAP:              "GET  /ISAPI/AccessControl/AcsCfg/capabilities",

  // ── Card reader config ────────────────────────────────────
  CARD_READER_CFG:          "GET  /ISAPI/AccessControl/CardReaderCfg/<cardReaderID>",
  SET_CARD_READER_CFG:      "PUT  /ISAPI/AccessControl/CardReaderCfg/<cardReaderID>",
  CARD_READER_CFG_CAP:      "GET  /ISAPI/AccessControl/CardReaderCfg/capabilities",

  // ── Card reader schedule (plan) ───────────────────────────
  CARD_READER_PLAN:         "GET  /ISAPI/AccessControl/CardReaderPlan/<cardReaderID>",
  SET_CARD_READER_PLAN:     "PUT  /ISAPI/AccessControl/CardReaderPlan/<cardReaderID>",
  CARD_READER_PLAN_CAP:     "GET  /ISAPI/AccessControl/CardReaderPlan/capabilities",

  // ── Card verification rule ────────────────────────────────
  CARD_VERIFY_RULE:         "GET  /ISAPI/AccessControl/CardVerificationRule",
  SET_CARD_VERIFY_RULE:     "PUT  /ISAPI/AccessControl/CardVerificationRule",
  CARD_VERIFY_RULE_CAP:     "GET  /ISAPI/AccessControl/CardVerificationRule/capabilities",
  CARD_VERIFY_RULE_PROGRESS:"GET  /ISAPI/AccessControl/CardVerificationRule/progress",

  // ── Anti-passback ─────────────────────────────────────────
  ANTI_PASSBACK_RESET:      "GET  /ISAPI/AccessControl/AntiPassback/resetRules",
  PUT_ANTI_PASSBACK_RESET:  "PUT  /ISAPI/AccessControl/AntiPassback/resetRules",
  ANTI_PASSBACK_TIME:       "GET  /ISAPI/AccessControl/AntiPassback/timeRange",
  ANTI_SNEAK_CFG:           "GET  /ISAPI/AccessControl/AntiSneakCfg",
  SET_ANTI_SNEAK_CFG:       "PUT  /ISAPI/AccessControl/AntiSneakCfg",
  ANTI_SNEAK_CFG_CAP:       "GET  /ISAPI/AccessControl/AntiSneakCfg/capabilities",
  CLEAR_ANTI_SNEAK:         "PUT  /ISAPI/AccessControl/ClearAntiSneak",
  CLEAR_ANTI_SNEAK_CAP:     "GET  /ISAPI/AccessControl/ClearAntiSneak/capabilities",
  CLEAR_ANTI_SNEAK_CFG:     "PUT  /ISAPI/AccessControl/ClearAntiSneakCfg",
  CLEAR_ANTI_SNEAK_CFG_CAP: "GET  /ISAPI/AccessControl/ClearAntiSneakCfg/capabilities",
  CARD_READER_ANTI_SNEAK:   "GET  /ISAPI/AccessControl/CardReaderAntiSneakCfg/<cardReaderID>",
  SET_CARD_READER_ANTI_SNEAK:"PUT /ISAPI/AccessControl/CardReaderAntiSneakCfg/<cardReaderID>",
  CARD_READER_ANTI_SNEAK_CAP:"GET /ISAPI/AccessControl/CardReaderAntiSneakCfg/capabilities",

  // ── User permission schedules ─────────────────────────────
  // Verify plan template
  VERIFY_PLAN_TEMPLATE:     "GET  /ISAPI/AccessControl/VerifyPlanTemplate/<templateNo>",
  SET_VERIFY_PLAN_TEMPLATE: "PUT  /ISAPI/AccessControl/VerifyPlanTemplate/<templateNo>",
  VERIFY_PLAN_TEMPLATE_CAP: "GET  /ISAPI/AccessControl/VerifyPlanTemplate/capabilities",
  // Verify week plan
  VERIFY_WEEK_PLAN:         "GET  /ISAPI/AccessControl/VerifyWeekPlanCfg/<templateNo>",
  SET_VERIFY_WEEK_PLAN:     "PUT  /ISAPI/AccessControl/VerifyWeekPlanCfg/<templateNo>",
  VERIFY_WEEK_PLAN_CAP:     "GET  /ISAPI/AccessControl/VerifyWeekPlanCfg/capabilities",
  // Verify holiday group
  VERIFY_HOLIDAY_GROUP:     "GET  /ISAPI/AccessControl/VerifyHolidayGroupCfg/<groupNo>",
  SET_VERIFY_HOLIDAY_GROUP: "PUT  /ISAPI/AccessControl/VerifyHolidayGroupCfg/<groupNo>",
  VERIFY_HOLIDAY_GROUP_CAP: "GET  /ISAPI/AccessControl/VerifyHolidayGroupCfg/capabilities",
  // Verify holiday plan
  VERIFY_HOLIDAY_PLAN:      "GET  /ISAPI/AccessControl/VerifyHolidayPlanCfg/<templateNo>",
  SET_VERIFY_HOLIDAY_PLAN:  "PUT  /ISAPI/AccessControl/VerifyHolidayPlanCfg/<templateNo>",
  VERIFY_HOLIDAY_PLAN_CAP:  "GET  /ISAPI/AccessControl/VerifyHolidayPlanCfg/capabilities",

  // User right plan template
  USER_RIGHT_PLAN:          "GET  /ISAPI/AccessControl/UserRightPlanTemplate/<templateNo>",
  SET_USER_RIGHT_PLAN:      "PUT  /ISAPI/AccessControl/UserRightPlanTemplate/<templateNo>",
  USER_RIGHT_PLAN_CAP:      "GET  /ISAPI/AccessControl/UserRightPlanTemplate/capabilities",
  // User right week plan
  USER_RIGHT_WEEK_PLAN:     "GET  /ISAPI/AccessControl/UserRightWeekPlanCfg/<templateNo>",
  SET_USER_RIGHT_WEEK_PLAN: "PUT  /ISAPI/AccessControl/UserRightWeekPlanCfg/<templateNo>",
  USER_RIGHT_WEEK_PLAN_CAP: "GET  /ISAPI/AccessControl/UserRightWeekPlanCfg/capabilities",
  // User right holiday group
  USER_RIGHT_HOLIDAY_GROUP: "GET  /ISAPI/AccessControl/UserRightHolidayGroupCfg/<groupNo>",
  SET_USER_RIGHT_HOLIDAY_GROUP:"PUT /ISAPI/AccessControl/UserRightHolidayGroupCfg/<groupNo>",
  USER_RIGHT_HOLIDAY_GROUP_CAP:"GET /ISAPI/AccessControl/UserRightHolidayGroupCfg/capabilities",
  // User right holiday plan
  USER_RIGHT_HOLIDAY_PLAN:  "GET  /ISAPI/AccessControl/UserRightHolidayPlanCfg/<templateNo>",
  SET_USER_RIGHT_HOLIDAY_PLAN:"PUT /ISAPI/AccessControl/UserRightHolidayPlanCfg/<templateNo>",
  USER_RIGHT_HOLIDAY_PLAN_CAP:"GET /ISAPI/AccessControl/UserRightHolidayPlanCfg/capabilities",

  // ── Door control schedules ────────────────────────────────
  DOOR_STATUS_PLAN:         "GET  /ISAPI/AccessControl/DoorStatusPlan/<planID>",
  SET_DOOR_STATUS_PLAN:     "PUT  /ISAPI/AccessControl/DoorStatusPlan/<planID>",
  DOOR_STATUS_PLAN_CAP:     "GET  /ISAPI/AccessControl/DoorStatusPlan/capabilities",
  DOOR_STATUS_PLAN_TEMPLATE:"GET  /ISAPI/AccessControl/DoorStatusPlanTemplate/<templateNo>",
  SET_DOOR_STATUS_PLAN_TEMPLATE:"PUT /ISAPI/AccessControl/DoorStatusPlanTemplate/<templateNo>",
  DOOR_STATUS_PLAN_TMPL_CAP:"GET  /ISAPI/AccessControl/DoorStatusPlanTemplate/capabilities",
  DOOR_STATUS_WEEK_PLAN:    "GET  /ISAPI/AccessControl/DoorStatusWeekPlanCfg/<templateNo>",
  SET_DOOR_STATUS_WEEK_PLAN:"PUT  /ISAPI/AccessControl/DoorStatusWeekPlanCfg/<templateNo>",
  DOOR_STATUS_WEEK_PLAN_CAP:"GET  /ISAPI/AccessControl/DoorStatusWeekPlanCfg/capabilities",
  DOOR_STATUS_HOLIDAY_GROUP:"GET  /ISAPI/AccessControl/DoorStatusHolidayGroupCfg/<groupNo>",
  SET_DOOR_STATUS_HOLIDAY_GROUP:"PUT /ISAPI/AccessControl/DoorStatusHolidayGroupCfg/<groupNo>",
  DOOR_STATUS_HOLIDAY_GROUP_CAP:"GET /ISAPI/AccessControl/DoorStatusHolidayGroupCfg/capabilities",
  DOOR_STATUS_HOLIDAY_PLAN: "GET  /ISAPI/AccessControl/DoorStatusHolidayPlanCfg/<templateNo>",
  SET_DOOR_STATUS_HOLIDAY_PLAN:"PUT /ISAPI/AccessControl/DoorStatusHolidayPlanCfg/<templateNo>",
  DOOR_STATUS_HOLIDAY_PLAN_CAP:"GET /ISAPI/AccessControl/DoorStatusHolidayPlanCfg/capabilities",

  // ── Multi-factor / group authentication ───────────────────
  MULTI_CARD_CFG:           "GET  /ISAPI/AccessControl/MultiCardCfg/<cardNo>",
  SET_MULTI_CARD_CFG:       "PUT  /ISAPI/AccessControl/MultiCardCfg/<cardNo>",
  MULTI_CARD_CFG_CAP:       "GET  /ISAPI/AccessControl/MultiCardCfg/capabilities",
  GROUP_CFG:                "GET  /ISAPI/AccessControl/GroupCfg/<groupID>",
  SET_GROUP_CFG:            "PUT  /ISAPI/AccessControl/GroupCfg/<groupID>",
  GROUP_CFG_CAP:            "GET  /ISAPI/AccessControl/GroupCfg/capabilities",
  CLEAR_GROUP_CFG:          "PUT  /ISAPI/AccessControl/ClearGroupCfg",
  CLEAR_GROUP_CFG_CAP:      "GET  /ISAPI/AccessControl/ClearGroupCfg/capabilities",

  // ── Event card linkage ────────────────────────────────────
  EVENT_CARD_LINKAGE:       "GET  /ISAPI/AccessControl/EventCardLinkageCfg/<linkageID>",
  SET_EVENT_CARD_LINKAGE:   "PUT  /ISAPI/AccessControl/EventCardLinkageCfg/<linkageID>",
  EVENT_CARD_LINKAGE_CAP:   "GET  /ISAPI/AccessControl/EventCardLinkageCfg/capabilities",
  EVENT_CARD_LINKAGE_SEARCH:"POST /ISAPI/AccessControl/EventCardLinkageCfg/search",
  EVENT_CARD_LINKAGE_DELETE:"PUT  /ISAPI/AccessControl/EventCardLinkageCfgDelete",
  CLEAR_EVENT_CARD_LINKAGE: "PUT  /ISAPI/AccessControl/ClearEventCardLinkageCfg",
  CLEAR_EVENT_CARD_LINKAGE_CAP:"GET /ISAPI/AccessControl/ClearEventCardLinkageCfg/capabilities",
  EVENT_CARD_NO_LIST:       "GET  /ISAPI/AccessControl/EventCardNoList",
  EVENT_CARD_NO_LIST_CAP:   "GET  /ISAPI/AccessControl/EventCardNoList/capabilities",
  EVENT_OPTIMIZATION:       "GET  /ISAPI/AccessControl/EventOptimizationCfg",
  SET_EVENT_OPTIMIZATION:   "PUT  /ISAPI/AccessControl/EventOptimizationCfg",
  EVENT_OPTIMIZATION_CAP:   "GET  /ISAPI/AccessControl/EventOptimizationCfg/capabilities",

  // ── QR code ───────────────────────────────────────────────
  QR_CODE_ENCRYPTION:       "PUT  /ISAPI/AccessControl/QRCodeEncryption",
  QR_CODE_ENCRYPTION_CAP:   "GET  /ISAPI/AccessControl/QRCodeEncryption/capabilities",
  QR_CODE_INFO:             "POST /ISAPI/AccessControl/QRCodeInfo",
  QR_CODE_INFO_CAP:         "GET  /ISAPI/AccessControl/QRCodeInfo/capabilities",
  QR_CODE_EVENT:            "POST /ISAPI/AccessControl/QRCodeEvent",
  QR_CODE_EVENT_CAP:        "GET  /ISAPI/AccessControl/QRCodeEvent/capabilities",

  // ── M1 card encryption ────────────────────────────────────
  M1_CARD_ENCRYPT:          "GET  /ISAPI/AccessControl/M1CardEncryptCfg",
  SET_M1_CARD_ENCRYPT:      "PUT  /ISAPI/AccessControl/M1CardEncryptCfg",
  M1_CARD_ENCRYPT_CAP:      "GET  /ISAPI/AccessControl/M1CardEncryptCfg/capabilities",

  // ── NFC / RFID ────────────────────────────────────────────
  NFC_CFG:                  "GET  /ISAPI/AccessControl/Configuration/NFCCfg",
  SET_NFC_CFG:              "PUT  /ISAPI/AccessControl/Configuration/NFCCfg",
  NFC_CFG_CAP:              "GET  /ISAPI/AccessControl/Configuration/NFCCfg/capabilities",
  RF_CARD_CFG:              "GET  /ISAPI/AccessControl/Configuration/RFCardCfg",
  SET_RF_CARD_CFG:          "PUT  /ISAPI/AccessControl/Configuration/RFCardCfg",
  RF_CARD_CFG_CAP:          "GET  /ISAPI/AccessControl/Configuration/RFCardCfg/capabilities",

  // ── Wiegand ───────────────────────────────────────────────
  WIEGAND_CFG:              "GET  /ISAPI/AccessControl/WiegandCfg/wiegandNo/<wiegandNo>",
  SET_WIEGAND_CFG:          "PUT  /ISAPI/AccessControl/WiegandCfg/wiegandNo/<wiegandNo>",
  WIEGAND_CFG_CAP:          "GET  /ISAPI/AccessControl/WiegandCfg/capabilities",
  WIEGAND_RULE:             "GET  /ISAPI/AccessControl/WiegandRuleCfg",
  SET_WIEGAND_RULE:         "PUT  /ISAPI/AccessControl/WiegandRuleCfg",
  WIEGAND_RULE_CAP:         "GET  /ISAPI/AccessControl/WiegandRuleCfg/capabilities",

  // ── Deploy info & arming ──────────────────────────────────
  DEPLOY_INFO:              "GET  /ISAPI/AccessControl/DeployInfo",
  DEPLOY_INFO_CAP:          "GET  /ISAPI/AccessControl/DeployInfo/capabilities",

  // ── Identity terminal ─────────────────────────────────────
  IDENTITY_TERMINAL:        "GET  /ISAPI/AccessControl/IdentityTerminal",
  SET_IDENTITY_TERMINAL:    "PUT  /ISAPI/AccessControl/IdentityTerminal",
  IDENTITY_TERMINAL_CAP:    "GET  /ISAPI/AccessControl/IdentityTerminal/capabilities",

  // ── Local attendance ──────────────────────────────────────
  LOCAL_ATTENDANCE_RULE:    "GET  /ISAPI/AccessControl/LocalAttendance/rule",
  SET_LOCAL_ATTENDANCE_RULE:"PUT  /ISAPI/AccessControl/LocalAttendance/rule",
  LOCAL_ATTENDANCE_RULE_CAP:"GET  /ISAPI/AccessControl/LocalAttendance/rule/capabilities",
  LOCAL_ATTENDANCE_WEEK_CAP:"GET  /ISAPI/AccessControl/LocalAttendance/weekPlan/capabilities",

  // ── Bulk clear operations ─────────────────────────────────
  CLEAR_PLANS_CFG:          "PUT  /ISAPI/AccessControl/ClearPlansCfg",
  CLEAR_PLANS_CFG_CAP:      "GET  /ISAPI/AccessControl/ClearPlansCfg/capabilities",
  CLEAR_PICTURE_CFG:        "PUT  /ISAPI/AccessControl/ClearPictureCfg",
  CLEAR_PICTURE_CFG_CAP:    "GET  /ISAPI/AccessControl/ClearPictureCfg/capabilities",
};

// ─────────────────────────────────────────────────────────────
// FACE LIBRARY (FDLib) ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const FACE_LIB = {
  CAP:                      "GET  /ISAPI/Intelligent/FDLib/capabilities",
  LIST:                     "GET  /ISAPI/Intelligent/FDLib",
  COUNT:                    "GET  /ISAPI/Intelligent/FDLib/Count",
  CREATE:                   "POST /ISAPI/Intelligent/FDLib",
  UPDATE:                   "PUT  /ISAPI/Intelligent/FDLib",
  DELETE:                   "DELETE /ISAPI/Intelligent/FDLib",

  // Face data in library
  FACE_ADD:                 "POST /ISAPI/Intelligent/FDLib/FaceDataRecord",
  FACE_APPLY:               "PUT  /ISAPI/Intelligent/FDLib/FDSetUp",           // overwrite
  FACE_MODIFY:              "PUT  /ISAPI/Intelligent/FDLib/FDModify",
  FACE_SEARCH:              "POST /ISAPI/Intelligent/FDLib/FDSearch",           // text search
  FACE_SEARCH_ALT:          "POST /ISAPI/Intelligent/FDLib/search",
  FACE_DELETE:              "PUT  /ISAPI/Intelligent/FDLib/FDSearch/Delete",
  FACE_PICTURE_UPLOAD:      "POST /ISAPI/Intelligent/FDLib/pictureUpload",

  // Search by picture comparison
  SEARCH_BY_PIC:            "POST /ISAPI/Intelligent/FDLib/searchByPic",

  // Face analysis (modeling)
  FACE_ANALYSIS_CAP:        "GET  /ISAPI/SDT/Face/pictureAnalysis/capabilities",
  FACE_ANALYSIS:            "POST /ISAPI/SDT/Face/pictureAnalysis",
};

// ─────────────────────────────────────────────────────────────
// VIDEO INTERCOM ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const INTERCOM = {
  DEVICE_ID:                "GET  /ISAPI/VideoIntercom/deviceId",
  SET_DEVICE_ID:            "PUT  /ISAPI/VideoIntercom/deviceId",
  DEVICE_ID_CAP:            "GET  /ISAPI/VideoIntercom/deviceId/capabilities",

  DEVICE_COMMUNICATION:     "GET  /ISAPI/VideoIntercom/deviceCommunication",
  SET_DEVICE_COMMUNICATION: "PUT  /ISAPI/VideoIntercom/deviceCommunication",
  DEVICE_COMM_CAP:          "GET  /ISAPI/VideoIntercom/deviceCommunication/capabilities",

  RELATED_DEVICE_ADDR:      "GET  /ISAPI/VideoIntercom/relatedDeviceAddress",
  SET_RELATED_DEVICE_ADDR:  "PUT  /ISAPI/VideoIntercom/relatedDeviceAddress",
  RELATED_DEVICE_ADDR_CAP:  "GET  /ISAPI/VideoIntercom/relatedDeviceAddress/capabilities",

  KEY_CFG:                  "GET  /ISAPI/VideoIntercom/keyCfg",
  KEY_CFG_BY_ID:            "GET  /ISAPI/VideoIntercom/keyCfg/<keyID>",
  SET_KEY_CFG:              "PUT  /ISAPI/VideoIntercom/keyCfg/<keyID>",

  OPERATION_TIME:           "GET  /ISAPI/VideoIntercom/operationTime",
  SET_OPERATION_TIME:       "PUT  /ISAPI/VideoIntercom/operationTime",
  OPERATION_TIME_CAP:       "GET  /ISAPI/VideoIntercom/operationTime/capabilities",

  CALL_SIGNAL:              "PUT  /ISAPI/VideoIntercom/callSignal",
  CALL_SIGNAL_CAP:          "GET  /ISAPI/VideoIntercom/callSignal/capabilities",
  CALL_STATUS:              "GET  /ISAPI/VideoIntercom/callStatus",
  CALL_STATUS_CAP:          "GET  /ISAPI/VideoIntercom/callStatus/capabilities",
  CALLER_INFO:              "GET  /ISAPI/VideoIntercom/callerInfo",
  CALLER_INFO_CAP:          "GET  /ISAPI/VideoIntercom/callerInfo/capabilities",

  WORK_STATUS:              "GET  /ISAPI/VideoIntercom/WorkStatus",

  ELEVATORS:                "GET  /ISAPI/VideoIntercom/Elevators/<elevatorID>",
  SET_ELEVATOR:             "PUT  /ISAPI/VideoIntercom/Elevators/<elevatorID>",
  CALL_ELEVATOR_CAP:        "GET  /ISAPI/VideoIntercom/callElevator/capabilities",

  SMART_LOCK_PARAM:         "GET  /ISAPI/VideoIntercom/SmartLock/lockParam",
  SMART_LOCK_PARAM_CAP:     "GET  /ISAPI/VideoIntercom/SmartLock/lockParam/capabilities",
};

// ─────────────────────────────────────────────────────────────
// SECURITY CONTROL PANEL (SecurityCP) ENDPOINTS
// ─────────────────────────────────────────────────────────────
export const SECURITY_CP = {
  CAPABILITIES:             "GET  /ISAPI/SecurityCP/capabilities",
  CONFIGURATION_CAP:        "GET  /ISAPI/SecurityCP/Configuration/capabilities",

  // Alarm Receiving Center
  ARC:                      "GET  /ISAPI/SecurityCP/Configuration/ARC",
  SET_ARC:                  "PUT  /ISAPI/SecurityCP/Configuration/ARC/<id>",
  ARC_CAP:                  "GET  /ISAPI/SecurityCP/Configuration/ARC/capabilities",
  ARC_MANUAL_TEST:          "PUT  /ISAPI/SecurityCP/Configuration/ARC/manualTest",
  ARC_MANUAL_TEST_CAP:      "GET  /ISAPI/SecurityCP/Configuration/ARC/manualTest/capabilities",
  ARC_MANUAL_TEST_STATUS:   "POST /ISAPI/SecurityCP/Configuration/ARC/manualTest/status",

  // PSTN
  PSTN_CFG:                 "GET  /ISAPI/SecurityCP/Configuration/PSTNCfg",
  SET_PSTN_CFG:             "PUT  /ISAPI/SecurityCP/Configuration/PSTNCfg/<id>",

  // Message sending
  MSG_SEND_ARC:             "GET  /ISAPI/SecurityCP/Configuration/messageSendARC",
  SET_MSG_SEND_ARC:         "PUT  /ISAPI/SecurityCP/Configuration/messageSendARC",
  MSG_SEND_ARC_CAP:         "GET  /ISAPI/SecurityCP/Configuration/messageSendARC/capabilities",
  MSG_SEND_CLOUD:           "GET  /ISAPI/SecurityCP/Configuration/messageSendCloud",
  SET_MSG_SEND_CLOUD:       "PUT  /ISAPI/SecurityCP/Configuration/messageSendCloud",
  MSG_SEND_DIRECT:          "GET  /ISAPI/SecurityCP/Configuration/messageSendDirect",
  SET_MSG_SEND_DIRECT:      "PUT  /ISAPI/SecurityCP/Configuration/messageSendDirect",
  MSG_SEND_MAIL:            "GET  /ISAPI/SecurityCP/Configuration/messageSendMail",
  MSG_SEND_MAIL_CAP:        "GET  /ISAPI/SecurityCP/Configuration/messageSendMail/capabilities",
  SET_MSG_SEND_PHONE:       "PUT  /ISAPI/SecurityCP/Configuration/messageSendPhoneAnvanced/<id>",

  // Zones
  ZONE:                     "GET  /ISAPI/SecurityCP/Zone/<zoneID>",

  // Network config
  NET_CFG:                  "GET  /ISAPI/SecurityCP/NetCfg/<id>",
  SET_NET_CFG:              "PUT  /ISAPI/SecurityCP/NetCfg/<id>",
  NET_CFG_CAP:              "GET  /ISAPI/SecurityCP/NetCfg/capabilities",

  // Report center
  REPORT_CENTER:            "GET  /ISAPI/SecurityCP/ReportCenterCfg/<id>",
  SET_REPORT_CENTER:        "PUT  /ISAPI/SecurityCP/ReportCenterCfg/<id>",
  REPORT_CENTER_CAP:        "GET  /ISAPI/SecurityCP/ReportCenterCfg/capabilities",

  // Extension module
  EXTENSION_MODULE:         "GET  /ISAPI/SecurityCP/Configuration/extensionModule",

  // Custom messages
  CUSTOM_MSG_LIST:          "GET  /ISAPI/SecurityCP/customMessage/searchCustomMessageList",
  CUSTOM_MSG_ADD:           "POST /ISAPI/SecurityCP/customMessage/addCustomMessage",
  CUSTOM_MSG_MODIFY:        "PUT  /ISAPI/SecurityCP/customMessage/modifyCustomMessage",
  CUSTOM_MSG_DELETE:        "POST /ISAPI/SecurityCP/customMessage/deleteCustomMessage",
};

// ─────────────────────────────────────────────────────────────
// COMMON FIELD VALUES & ENUM CONSTANTS
// ─────────────────────────────────────────────────────────────

/** Remote door control commands */
export const DOOR_CMD = {
  OPEN:          "open",
  CLOSE:         "close",
  REMAIN_OPEN:   "remain_open",
  REMAIN_CLOSED: "remain_closed",
  LOCK:          "lock",
  UNLOCK:        "unlock",
};

/** Card types */
export const CARD_TYPE = {
  NORMAL:         "normalCard",
  VISITOR:        "visitorCard",
  BLACKLIST:      "blackCard",
  SUPER:          "superCard",
  PATROL:         "patrolCard",
  DURESS:         "duressCard",
  DISABLE:        "disableCard",
  RETURN:         "returnCard",
};

/** Person types */
export const PERSON_TYPE = {
  NORMAL:         "normal",
  VISITOR:        "visitor",
  BLACKLIST:      "blackList",
  VIP:            "vip",
};

/** Face recognition modes */
export const FACE_RECOGNIZE_MODE = {
  FACE_ONLY:       "faceRecognition",
  FACE_AND_CARD:   "faceAndCard",
  CARD_ONLY:       "card",
  FACE_OR_CARD:    "faceOrCard",
};

/** Authentication modes (verifyMode in AcsCfg) */
export const VERIFY_MODE = {
  CARD:              "cardOrFace",
  FACE:              "faceOrCard",
  CARD_AND_FACE:     "cardAndFace",
  FINGERPRINT:       "fingerprint",
  CARD_AND_FP:       "cardAndFingerprint",
  FACE_AND_FP:       "faceAndFingerprint",
  CARD_FP_FACE:      "cardAndFingerprintAndFace",
  PASSWORD:          "password",
  CARD_AND_PASSWORD: "cardAndPassword",
};

/** Event major types (for AcsEvent search) */
export const ACS_EVENT_MAJOR_TYPE = {
  ALARM:      1,    // 0x1
  EXCEPTION:  2,    // 0x2
  OPERATION:  3,    // 0x3
  INFO:       4,    // 0x4
  OTHER:      5,    // 0x5
};

/** Door status */
export const DOOR_STATUS = {
  CLOSED:         "close",
  OPEN:           "open",
  REMAIN_OPEN:    "remain_open",
  REMAIN_CLOSED:  "remain_closed",
};

/** Lock power-off behavior */
export const LOCK_POWEROFF = {
  REMAIN_OPEN:    "remainOpen",
  REMAIN_CLOSED:  "remainClosed",
};

/** Wiegand protocol */
export const WIEGAND_PROTOCOL = {
  W26:   "wiegand26",
  W34:   "wiegand34",
  W66:   "wiegand66",
};

/** Time sync modes */
export const TIME_SYNC_MODE = {
  MANUAL:    "manual",
  NTP:       "NTP",
  SATELLITE: "satellite",
  PLATFORM:  "platform",
};

/** HTTP host notification protocol */
export const HTTP_HOST_PROTOCOL = {
  HTTP:  "HTTP",
  HTTPS: "HTTPS",
};

/** Subscription event types (for subscribeEvent) */
export const SUBSCRIBE_EVENT_TYPE = {
  ALL:              "all",
  MOTION:           "VMD",
  TAMPER:           "fieldDetection",
  ACCESS:           "AccessControllerEvent",
  ALARM_INPUT:      "IO",
};

// ─────────────────────────────────────────────────────────────
// HTTP HELPER
// Usage:
//   const url = buildUrl("192.168.1.100", "/ISAPI/AccessControl/UserInfo/Search", "json");
//   const res = await fetch(url, { method: "POST", ... });
// ─────────────────────────────────────────────────────────────
export function buildUrl(host, path, format = "json", port = 80, useHttps = false) {
  const proto = useHttps ? "https" : "http";
  const fmt   = format ? `?format=${format}` : "";
  return `${proto}://${host}:${port}${path}${fmt}`;
}

/**
 * Parse the method and path from a constant string like "POST /ISAPI/..."
 * @param {string} entry  - constant value e.g. ACCESS.USER_SEARCH
 * @returns {{ method: string, path: string }}
 */
export function parseEndpoint(entry) {
  const [method, path] = entry.trim().split(/\s+/);
  return { method, path };
}
