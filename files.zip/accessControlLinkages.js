/**
 * Access Control Event Linkage Types
 * Source: Hikvision Access Control Event Types and Event Linkage Types
 * KAIHOME S.R.L. - jcgonzalez.01@gmail.com
 *
 * Used for event card linkages. Four major linkage types:
 *   0 = Device Event Linkage
 *   1 = Alarm Input Event Linkage
 *   2 = Access Control Point Event Linkage
 *   3 = Authentication Unit Event Linkage
 */

// ─────────────────────────────────────────────
// 0 - DEVICE EVENT LINKAGE
// ─────────────────────────────────────────────
export const DEVICE_EVENT_LINKAGE = {
  0:  "Access Controller Tampering Alarm",
  1:  "No Memory Alarm",
  2:  "Network Disconnected",
  3:  "Network Connected",
  4:  "Low Battery Voltage",
  5:  "Battery Fully Charged",
  6:  "AC Power Off",
  7:  "AC Power On",
  8:  "SD Card Full Alarm",
  9:  "Capture Linkage Event Alarm",
  10: "Low Face Picture Quality",
  11: "Low Fingerprint Picture Quality",
  12: "Low Battery Voltage",
  13: "Battery Fully Charged",
  14: "Fire Input Short Circuit Attempts Alarm",
  15: "Fire Input Open Circuit Attempts Alarm",
  16: "Fire Input Alarm Restored",
  17: "RS485 Loop of Main Access Controller Disconnected",
  18: "RS485 Loop of Main Access Controller Connected",
  19: "Distributed Access Controller Offline",
  20: "Distributed Access Controller Online",
  21: "Downstream RS485 Loop of Distributed Access Control Disconnected",
  22: "Downstream RS485 Loop of Distributed Access Control Connected",
  23: "Distributed Elevator Controller Online",
  24: "Distributed Elevator Controller Offline",
  25: "Fire Button Pressed",
  26: "Fire Button Released",
  27: "Maintenance Button Pressed",
  28: "Maintenance Button Released",
  29: "Panic Button Pressed",
  30: "Panic Button Released",
  32: "Communication with Anti-passing Back Server Failed",
  33: "Communication with Anti-passing Back Server Restored",
  34: "Remotely Armed",
  35: "Remotely Disarmed",
  36: "Motor or Sensor Exception",
  37: "CAN Bus Exception",
  38: "CAN Bus Restored",
  39: "Too High Pedestal Temperature",
  40: "Active Infrared Intrusion Detector Exception",
  41: "Active Infrared Intrusion Detector Restored",
  42: "Communication with Light Board Failed",
  43: "Communication with Light Board Restored",
  44: "Communication with IR Adaptor Failed",
  45: "Communication with IR Adaptor Restored",
  46: "Lane Controller Tampering Alarm",
  47: "Lane Controller Tampering Alarm Restored",
  48: "Lane Controller Fire Input Alarm",
  49: "Lane Controller Fire Input Alarm Restored",
  50: "Staying Event",
  51: "No Memory for Unreported and Access Granted Events",
  52: "Fire Input Alarm",
  53: "No-Mask Alarm",
  54: "Upload Fire Alarm Matrix",
  55: "Lock Health Information Exception",
  56: "Unlock Health Information Exception",
  57: "Upload Network Camera Event",
  58: "Optional Board Offline",
  59: "Restore Optional Board",
  60: "Access Module Fire Input Short Circuit Alarm",
  61: "Restore Access Module Fire Input",
  62: "Access Module Tampering Alarm",
  63: "Restore Access Module Tampering Alarm",
  64: "Panic Alarm",
  65: "Consultation Calling",
  66: "Main Station Calling",
  67: "VoIP Calling",
  68: "Terminal Zone Alarm",
  69: "Terminal Tampering Alarm",
  70: "Terminal: Sudden Increase/Decrease of Sound Intensity Alarm",
};

// ─────────────────────────────────────────────
// 1 - ALARM INPUT EVENT LINKAGE
// ─────────────────────────────────────────────
export const ALARM_INPUT_EVENT_LINKAGE = {
  0: "Zone Short Circuit Attempts Alarm",
  1: "Zone Open Circuit Attempts Alarm",
  2: "Zone Exception Alarm",
  3: "Zone Alarm Restored",
  4: "Alarm Input Alarm",
  5: "Alarm Input Alarm Restored",
  6: "I/O Port Short Circuit Alarm",
};

// ─────────────────────────────────────────────
// 2 - ACCESS CONTROL POINT EVENT LINKAGE
// (doors, elevators, etc.)
// ─────────────────────────────────────────────
export const ACCESS_CONTROL_POINT_EVENT_LINKAGE = {
  0:  "Open Door with First Card Started",
  1:  "Open Door with First Card Ended",
  2:  "Remain Open Started",
  3:  "Remain Open Ended",
  4:  "Remain Closed Started",
  5:  "Remain Closed Ended",
  6:  "Door Unlocked",
  7:  "Door Locked",
  8:  "Exit Button Pressed",
  9:  "Exit Button Released",
  10: "Door Open (Contact)",
  11: "Door Closed (Contact)",
  12: "Door Abnormally Open (Contact)",
  13: "Door Open Timed Out (Contact)",
  14: "Door Remotely Open",
  15: "Door Remotely Closed",
  16: "Remain Open Remotely",
  17: "Remain Closed Remotely",
  18: "Card Not in Multiple Authentication Group",
  19: "Card Not in Multiple Authentication Duration",
  20: "Multiple Authentication Mode: Super Password Authentication Failed",
  21: "Multiple Authentication Mode: Remote Authentication Failed",
  22: "Multiple Authentication Completed",
  23: "Multiple Authentication: Remotely Open Door",
  24: "Multiple Authentication: Super Password Authentication Completed",
  25: "Multiple Authentication: Repeated Authentication Failed",
  26: "Multiple Authentication Timed Out",
  27: "Remote Capture",
  28: "Doorbell Ring",
  29: "Secure Door Control Unit Tampering Alarm",
  30: "Center Event",
  31: "First Card Authentication Started",
  32: "First Card Authentication End",
  33: "Lock Input Short Circuit Attempts Alarm",
  34: "Lock Input Open Circuit Attempts Alarm",
  35: "Lock Input Exception Alarm",
  36: "Contact Input Short Circuit Attempts Alarm",
  37: "Contact Input Open Circuit Attempts Alarm",
  38: "Contact Input Exception Alarm",
  39: "Exit Button Input Short Circuit Attempts Alarm",
  40: "Exit Button Input Open Circuit Attempts Alarm",
  41: "Exit Button Input Exception Alarm",
  42: "Unlocking Exception",
  43: "Unlocking Timed Out",
  44: "Unauthorized First Card Opening Failed",
  45: "Call Elevator Relay Open",
  46: "Call Elevator Relay Closed",
  47: "Auto Button Relay Open",
  48: "Auto Button Relay Closed",
  49: "Button Relay Open",
  50: "Button Relay Closed",
  51: "Visitor Calling Elevator",
  52: "Resident Calling Elevator",
  53: "Valid Message",
  54: "Invalid Message",
  55: "Tailgating",
  56: "Reverse Passing",
  57: "Force Collision",
  58: "Climbing Over",
  59: "Passing Timed Out",
  60: "Intrusion Alarm",
  61: "Authentication Failed When Free Passing",
  62: "Barrier Obstructed",
  63: "Barrier Restored",
  64: "Door Closed via Keyfob",
  65: "Door Opened via Keyfob",
  66: "Remain Open via Keyfob",
};

// ─────────────────────────────────────────────
// 3 - AUTHENTICATION UNIT EVENT LINKAGE
// (card readers, fingerprint modules, etc.)
// ─────────────────────────────────────────────
export const AUTH_UNIT_EVENT_LINKAGE = {
  0:   "Duress Alarm",
  1:   "Card Reader Tampering Alarm",
  2:   "Valid Card Authentication Completed",
  3:   "Card and Password Authentication Completed",
  4:   "Card and Password Authentication Failed",
  5:   "Card and Password Authentication Timed Out",
  6:   "Card Authentication Attempts Reach Limit",
  7:   "No Permission for Card",
  8:   "Invalid Card Swiping Time Period",
  9:   "Expired Card",
  10:  "Card No. Not Exist",
  11:  "Anti-passing Back Authentication Failed",
  12:  "Interlocking Door Not Closed",
  13:  "Fingerprint Matched",
  14:  "Fingerprint Mismatched",
  15:  "Card and Fingerprint Authentication Completed",
  16:  "Card and Fingerprint Authentication Failed",
  17:  "Card and Fingerprint Authentication Timed Out",
  18:  "Card, Fingerprint, and Password Authentication Completed",
  19:  "Card and Fingerprint Authentication Failed",
  20:  "Card and Fingerprint Authentication Timed Out",
  21:  "Fingerprint and Password Authentication Completed",
  22:  "Fingerprint and Password Authentication Failed",
  23:  "Fingerprint and Password Authentication Timed Out",
  24:  "Fingerprint Not Exist",
  42:  "Employee ID and Fingerprint Authentication Completed",
  43:  "Employee ID and Fingerprint Authentication Failed",
  44:  "Employee ID and Fingerprint Authentication Timed Out",
  45:  "Employee ID, Fingerprint, and Password Authentication Completed",
  46:  "Employee ID, Fingerprint, and Password Authentication Failed",
  47:  "Employee ID, Fingerprint, and Password Authentication Timed Out",
  52:  "Employee ID and Password Authentication Completed / Failed",  // duplicado en doc original
  53:  "Employee ID and Password Authentication Timed Out",
  57:  "Authentication Failed When Door Remain Closed or Door in Sleeping Mode",
  58:  "Authentication Failed When Authentication Schedule in Sleeping Mode",
  59:  "Card Encryption Verification Failed",
  60:  "Anti-passing Back Server Response Failed",
  61:  "Password Mismatched",
  62:  "Employee ID Not Exist",
  63:  "Combined Authentication Completed",
  64:  "Combined Authentication Timed Out",
  65:  "Authentication Type Mismatched",
  67:  "Maximum Password Authentication Failure Attempts",
  68:  "Password Authenticated",
  69:  "Password Authentication Failed",
  70:  "QR Code Authenticated",
  71:  "QR Code Authentication Failed",
  72:  "Resident Authorization Authenticated",
  73:  "Bluetooth Authenticated",
  74:  "Bluetooth Authentication Failed",
  75:  "Authentication Failed: Invalid M1 Card",
  76:  "Verifying CPU Card Encryption Failed",
  77:  "Disabling NFC Verification Failed",
  78:  "EM Card Recognition Disabled",
  79:  "M1 Card Recognition Disabled",   // raw doc shows "7" (typo), corrected to 79
  80:  "CPU Card Recognition Disabled",
  81:  "ID Card Recognition Disabled",
  82:  "Importing Key to Card Failed",
  83:  "Verifying Desfire Card Encryption Failed",
  84:  "Desfire Card Reading Disabled",
  85:  "Access Granted by Iris",
  86:  "Access Denied by Iris",
  87:  "Iris Anti-Spoofing Detection Failed",
  88:  "FeliCa Card Recognition Disabled",
  89:  "QR Code Recognized",
  90:  "Voiceprint Anti-Spoofing Detection Failed",
  91:  "Voiceprint Authentication Failed",
  92:  "Electrostatic Discharge Testing Passed",
  93:  "Electrostatic Discharge Testing Not Passed (Door Opened)",
  94:  "Electrostatic Discharge Testing Not Passed (Door Not Opened)",
  95:  "Electrostatic Discharge Testing Timed Out",
  96:  "Person and Social Security Card Matched",
  97:  "Person and Social Security Card Mismatched",
  98:  "Access Granted by Palmprint and Palm Veins",
  99:  "Access Denied by Palmprint and Palm Veins",
  100: "Blocklist Event",
};

// ─────────────────────────────────────────────
// MAJOR LINKAGE TYPE MAP
// ─────────────────────────────────────────────
export const MAJOR_LINKAGE_TYPES = {
  0: { label: "Device Event Linkage",               events: DEVICE_EVENT_LINKAGE },
  1: { label: "Alarm Input Event Linkage",          events: ALARM_INPUT_EVENT_LINKAGE },
  2: { label: "Access Control Point Event Linkage", events: ACCESS_CONTROL_POINT_EVENT_LINKAGE },
  3: { label: "Authentication Unit Event Linkage",  events: AUTH_UNIT_EVENT_LINKAGE },
};

// ─────────────────────────────────────────────
// HELPER: resolve linkage description
// Usage: getLinkageDescription(2, 6) → "Door Unlocked"
// ─────────────────────────────────────────────
export function getLinkageDescription(majorType, minorType) {
  const major = MAJOR_LINKAGE_TYPES[majorType];
  if (!major) return `Unknown linkage major type (${majorType})`;
  const desc = major.events[minorType];
  return desc ?? `Unknown minor type (${minorType}) in ${major.label}`;
}
